import React from "react";
import {
  FaCirclePlay,
  FaRotateRight,     // ⬅️ FaRedo was renamed
  FaGlobe,
  FaSatellite,
  FaTowerBroadcast,
} from "react-icons/fa6";
import "./ControlPanel.css";

function ControlPanel({
  startSimulation,
  restartSimulation,
  simulationStarted,
  viewMode,
  setViewMode,
  simulationModeEnabled,
  setSimulationModeEnabled,
}) {
  return (
    <div className="card controls-card">
      <h4>⚙ Control Options</h4>

      {/* Start + Restart buttons */}
      <div className="control-buttons">
        <button
          className="btn start-btn"
          onClick={startSimulation}
        >
          <FaCirclePlay /> {simulationStarted ? "Continue Simulation" : "Start Simulation"}
        </button>
        <button className="btn restart-btn" onClick={restartSimulation}>
         <FaRotateRight /> Restart
        </button>
      </div>

      {/* Real-Time Mode Toggle */}
      <div className="control-toggle">
        <FaTowerBroadcast className="control-icon" />
        <span>Real-Time Mode</span>
        <label className="switch">
          <input
            type="checkbox"
            checked={!simulationModeEnabled}
            onChange={() => setSimulationModeEnabled(!simulationModeEnabled)}
          />
          <span className="slider round"></span>
        </label>
      </div>

      {/* Globe Mode Toggle */}
      <div className="control-toggle">
        <FaGlobe className="control-icon" />
        <span>Globe Mode</span>
        <label className="switch">
          <input
            type="checkbox"
            checked={viewMode === "globe"}
            onChange={() =>
              setViewMode(viewMode === "globe" ? "map" : "globe")
            }
          />
          <span className="slider round"></span>
        </label>
      </div>

      {/* Space Mode Toggle */}
      <div className="control-toggle">
        <FaSatellite className="control-icon" />
        <span>Space Mode</span>
        <label className="switch">
          <input
            type="checkbox"
            checked={viewMode === "space"}
            onChange={() =>
              setViewMode(viewMode === "space" ? "map" : "space")
            }
          />
          <span className="slider round"></span>
        </label>
      </div>
    </div>
  );
}

export default ControlPanel;
