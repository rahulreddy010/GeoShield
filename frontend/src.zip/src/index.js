import React from "react";
import { createRoot } from "react-dom/client";
import App from "./App";
import "leaflet/dist/leaflet.css";
import "./index.css";  // now exists

const container = document.getElementById("root");
const root = createRoot(container);
root.render(<App />);
